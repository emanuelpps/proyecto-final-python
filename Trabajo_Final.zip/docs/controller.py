import view
from tkinter import Tk

if __name__ == "__main__":
    root = Tk()
    view.MainView(root)
    root.mainloop()
